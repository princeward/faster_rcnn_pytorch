#--------------------------------------------------------------------------
#
# File Name:      main.py
# Date Created:   2018/05/29
# Date Modified:  2018/05/29
#
# Author:         Eric Cristofalo
# Contact:        eric.cristofalo@gmail.com
#
# Description:    Main code for pelorus
#
#--------------------------------------------------------------------------

import os
import random
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim as optim
import torch.utils.data
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np
import time
import math