#--------------------------------------------------------------------------
#
# File Name:      dataloader.py
# Date Created:   2018/05/29
# Date Modified:  2018/05/29
#
# Author:         Eric Cristofalo
# Contact:        eric.cristofalo@gmail.com
#
# Description:    Data loader for KITTI 3D object benchmark:
#                 http://www.cvlibs.net/datasets/kitti/eval_object.php?obj_benchmark=3d
#
#                 Data: left image
#                 disparity map
#                 Labels: 
#
#--------------------------------------------------------------------------

def dataloader(filepath):
    classes = [d for d in os.listdir(filepath) if os.path.isdir(os.path.join(filepath, d))]
    image = [img for img in classes if img.find('frames_cleanpass') > -1]
    disp  = [dsp for dsp in classes if dsp.find('disparity') > -1]

    return 1;