%--------------------------------------------------------------------------
%
% File Name:      visualizing_depth_maps.m
% Date Created:   2018/05/29
% Date Modified:  2018/05/29
%
% Author:         Eric Cristofalo
% Contact:        eric.cristofalo@gmail.com
%
% Description:    Converting uint16 disparity images to RGB depth maps for 
%                 nice visualization. 
%
%--------------------------------------------------------------------------

%%

% Input directory
folderPath = '/Users/ericcristofalo/Desktop/disparity/';
imageFormat = 'png';

% Output directory
outputPath = '/Users/ericcristofalo/Desktop/depth_visualization/';
if exist(outputPath,'file')~=7
   mkdir(outputPath);
end

% Find files in directory
list = dir(fullfile(folderPath,['*.',imageFormat]));
numFiles = size(list,1);

% Process and save each file
for i = 1:numFiles
   
   % Read current image
   imName = list(i).name;
   im = imread([folderPath,imName]);
   imSize = size(im);
   
   % Scale to true depth
   baseline = 0.54; % ~54cm from Vision meets Robotics: The KITTI Dataset
   focal = 721; % pixels from https://github.com/mrharicot/monodepth/issues/118
   imdepth =  (baseline*focal)./(double(im)/256);
   
   % Color depth image
   scaleRange = [(baseline*focal)/(max(double(im(:)))/256),...
                 (baseline*focal)/(min(double(im(:)))/256)];
   imrgb = scale2RGB(imdepth,scaleRange,'red2blue');
      
   % Add depth scale color bar
   colorBarThick = 50;
   colorBarTextThick = 55;
   colorBarSpace = 10;
   minLabel = ['0'];
   middleLabel = 'Pixel Depth Error (%)';
   maxLabel = ['',num2str(scaleRange(end))];
   colorDirection = 'red2blue';
   imcolorbar = linspace(scaleRange(end),scaleRange(1),imSize(1))';
   imcolorbar = repmat(imcolorbar,1,colorBarThick);
   imcolorbar = scale2RGB(imcolorbar,scaleRange,colorDirection);
   imrgb_bar = 255*ones(imSize(1),imSize(2)+colorBarSpace+colorBarThick+colorBarTextThick,3);
   imrgb_bar(:,1:imSize(2),:) = imrgb;
   imrgb_bar(:,(imSize(2)+colorBarSpace+1):imSize(2)+colorBarSpace+colorBarThick,:) = imcolorbar;
   imrgb_bar = uint8(imrgb_bar);
   
   % Add text to scale color bar
   text_font = 'Times';
   text_fontSize = 20;
   text_plot = sprintf('%.1f',scaleRange(2));
   text_pos = [imSize(2)+colorBarSpace+colorBarThick+1,1];
   imrgb_bar = insertText(imrgb_bar,text_pos,text_plot,...
      'BoxColor','white','FontSize',text_fontSize,...
      'Font',text_font,'TextColor','black');
   text_plot = 'depth';
   text_pos = [imSize(2)+colorBarSpace+colorBarThick+1,imSize(1)/2-35];
   imrgb_bar = insertText(imrgb_bar,text_pos,text_plot,...
      'BoxColor','white','FontSize',text_fontSize,...
      'Font',text_font,'TextColor','black');
   text_plot = '(m)';
   text_pos = [imSize(2)+colorBarSpace+colorBarThick+1,imSize(1)/2-10];
   imrgb_bar = insertText(imrgb_bar,text_pos,text_plot,...
      'BoxColor','white','FontSize',text_fontSize,...
      'Font',text_font,'TextColor','black');
   text_plot = sprintf('%.1f',scaleRange(1));
   text_pos = [imSize(2)+colorBarSpace+colorBarThick+1,imSize(1)-35];
   imrgb_bar = insertText(imrgb_bar,text_pos,text_plot,...
      'BoxColor','white','FontSize',text_fontSize,...
      'Font',text_font,'TextColor','black');
   
   % Display image
   figure(1); %clf(1);
   pos = get(1,'position');
   set(1,'position',[pos(1:2),678,737]);
   subplot(3,1,1);
   imshow(im); impixelinfo;
   title('Raw Disparity Image from PSMNet');
   subplot(3,1,2);
   imagesc(imdepth); axis equal; impixelinfo;
   title('Transformed Depth Image');
   subplot(3,1,3);
   imshow(imrgb_bar); impixelinfo;
   title('Visualized RGB Depth Image with Colorbar');
   
   % Save output image
   imwrite(imrgb_bar,[outputPath,imName]);
   
end

